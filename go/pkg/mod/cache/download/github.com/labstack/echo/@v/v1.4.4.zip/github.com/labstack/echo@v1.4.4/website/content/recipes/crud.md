---
title: CRUD
menu:
  side:
    parent: recipes
    weight: 2
---

### Server

`server.go`

{{< embed "crud/server.go" >}}

### Maintainers

- [vishr](https://github.com/vishr)

### [Source Code](https://github.com/vishr/echo-recipes/blob/master/v1/crud)
