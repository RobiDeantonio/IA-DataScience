---
title: Website
menu:
  side:
    parent: recipes
    weight: 4
---

### Server

`server.go`

{{< embed "website/server.go" >}}

### Client

`index.html`

{{< embed "website/public/index.html" >}}

### Maintainers

- [vishr](https://github.com/vishr)

### [Source Code](https://github.com/vishr/echo-recipes/blob/master/v1/website)
