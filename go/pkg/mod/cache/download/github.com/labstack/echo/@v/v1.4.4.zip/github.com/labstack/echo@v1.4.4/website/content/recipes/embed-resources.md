---
title: Embed Resources
menu:
  side:
    identifier: "embed-resources"
    parent: recipes
    weight: 14
---

### With go.rice

`rice.go`

{{< embed "embed-resources/rice.go" >}}

### Maintainers

- [caarlos0](https://github.com/caarlos0)

### [Source Code](https://github.com/vishr/echo-recipes/blob/master/v1/rice)
