---
title: Subdomains
menu:
  side:
    parent: recipes
    weight: 10
---

`server.go`

{{< embed "subdomains/server.go" >}}

### Maintainers

- [axdg](https://github.com/axdg)
- [vishr](https://github.com/vishr)

### [Source Code](https://github.com/vishr/echo-recipes/blob/master/v1/subdomains)
